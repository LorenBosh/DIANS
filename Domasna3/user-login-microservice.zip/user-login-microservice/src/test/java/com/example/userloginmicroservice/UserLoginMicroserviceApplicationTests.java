package com.example.userloginmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLoginMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
